package hus.oop.lab.lab03;

import java.util.Scanner;

public interface SortingAndSearching {
    public static void main(String[] args) {
        //testLinearSearch(); //Exercise 2.1
        //testBinarySearch(); //Exercise 2.2
        //testBubbleSort(); //Exercise 2.3
        //testSelectionSort(); //Exercise 2.4
        testInsertionSort(); //Exercise 2.50
    }

    //*********************Exercise 2.1 Linear Search*********************
    public static boolean linearSearch(int[] array, int key) {
        for (int i = 0; i < array.length; i++)
            if (array[i] == key)
                return true;

        return false;
    }

    public static int linearSearchIndex(int[] array, int key) {
        for (int i = 0; i < array.length; i++)
            if (array[i] == key)
                return i + 1;

        return 0;
    }

    public static void testLinearSearch() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter size of array: ");
        int size = in.nextInt();

        System.out.print("Enter " + size + " numbers: ");
        int array[] = new int[size];
        for (int i = 0; i < size; i++)
            array[i] = in.nextInt();

        System.out.print("Enter the key: ");
        int key = in.nextInt();

        if (linearSearch(array, key))
            System.out.println(key + " is found in array!");
        else
            System.out.println(key +" is NOT found in array!");

        if (linearSearchIndex(array, key) != 0)
            System.out.println(key + " is in index " + linearSearchIndex(array, key));
        else
            System.out.println(key + " is NOT found in array!");
    }

    //*********************Exercise 2.2 Binary Search*********************
    public static boolean binarySearch(int[] array, int key, int fromIdx, int toIdx) {
        if (fromIdx == toIdx - 1)// Terminating one-element list
            if (key == array[fromIdx]) return true;
            else return false; // Not found
        else {
            int middleIdx = (fromIdx + toIdx) / 2;
            if (key == array[middleIdx]) return true;
            else if (key < array[middleIdx]) toIdx = middleIdx;
            else fromIdx = middleIdx + 1;
            return binarySearch(array, key, fromIdx, toIdx); // Recursive call
        }
    }

    public static void testBinarySearch() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter size of array: ");
        int size = in.nextInt();

        System.out.print("Enter " + size + " numbers: ");
        int array[] = new int[size];
        for (int i = 0; i < size; i++)
            array[i] = in.nextInt();

        System.out.print("Enter the key: ");
        int key = in.nextInt();

        if (binarySearch(array, key, 0, size - 1))
            System.out.println(key + " is found in array!");
        else
            System.out.println(key +" is NOT found in array!");
    }

    //*********************Exercise 2.3 Bubble Sort*********************
    public static void bubbleSort(int[] array) {
        int n = array.length;
        boolean swapped;

        do {
            swapped = false; // Reset for each pass
            for (int i = 1; i < n; ++i) {
                // Swap if this pair is out of order
                if (array[i - 1] > array[i]) {
                    swap(array, i - 1, i);
                    swapped = true; // Update flag
                }
            }
            n--; // One item sorted after each pass
        } while (swapped); // Repeat another pass if swapping occurred, otherwise done
    }

    public static void swap(int[] array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    public static void testBubbleSort() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter size of array: ");
        int size = in.nextInt();

        System.out.print("Enter " + size + " numbers: ");
        int array[] = new int[size];
        for (int i = 0; i < size; i++)
            array[i] = in.nextInt();

        bubbleSort(array);
        System.out.print("Array after sort: ");
        for (int i : array)
            System.out.print(i + " ");
    }

    //*********************Exercise 2.4 Selection Sort*********************
    public static void selectionSort(int[] array) {
        int n = array.length;

        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (array[j] < array[minIndex]) {
                    minIndex = j;
                }
            }
            // Swap the found minimum element with the first element
            swap(array, i, minIndex);
        }
    }

    public static void testSelectionSort() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter size of array: ");
        int size = in.nextInt();

        System.out.print("Enter " + size + " numbers: ");
        int array[] = new int[size];
        for (int i = 0; i < size; i++)
            array[i] = in.nextInt();

        selectionSort(array);
        System.out.print("Array after sort: ");
        for (int i : array)
            System.out.print(i + " ");
    }

    //*********************Exercise 2.5 Insertion Sort*********************
    public static void insertionSort(int[] array) {
        int n = array.length;

        for (int i = 1; i < n; i++) {
            int key = array[i];
            int j = i - 1;

            // Move elements of array[0..i-1] that are greater than key
            // to one position ahead of their current position
            while (j >= 0 && array[j] > key) {
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = key;
        }
    }

    public static void testInsertionSort() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter size of array: ");
        int size = in.nextInt();

        System.out.print("Enter " + size + " numbers: ");
        int array[] = new int[size];
        for (int i = 0; i < size; i++)
            array[i] = in.nextInt();

        insertionSort(array);
        System.out.print("Array after sort: ");
        for (int i : array)
            System.out.print(i + " ");
    }
}
