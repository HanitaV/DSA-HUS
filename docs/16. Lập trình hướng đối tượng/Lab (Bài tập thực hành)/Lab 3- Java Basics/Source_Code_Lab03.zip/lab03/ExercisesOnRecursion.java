package hus.oop.lab.lab03;

import java.util.Scanner;

public class ExercisesOnRecursion {
    public static void main(String[] args) {
        //testFactorial(); //Exercise 1.1
        //testFibonacci(); //Exercise 1.2
        //testLen(); //Exercise 1.3
        testGcd(); //Exercise 1.4
    }

    //*********************Exercise 1.1 Factorial Recusive*********************
    public static int factorial(int n) {
        if (n == 0)
            return  1;

        return n * factorial(n - 1);
    }

    public static void testFactorial() {
        Scanner in  = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = in.nextInt();
        System.out.println("Factorial of " + num + " is " + factorial(num));
    }

    //*********************Exercise 1.2 Fibonacci*********************
    public static int fibonacci(int n) {
        if (n <= 1)
            return  n;

        return fibonacci(n - 1) + fibonacci(n - 2);
    }

    public static void testFibonacci() {
        Scanner in  = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = in.nextInt();
        System.out.println("Fibonacci of " + num + " is " + fibonacci(num));
    }

    //*********************Exercise 1.3 Length of a Running Number Sequence*********************
    public static int numOfDigits(int n) {
        int digits = 0;
        while (n != 0) {
            ++digits;
            n /= 10;
        }

        return  digits;
    }
    public static int len(int n) {
        if (n <= 9)
            return n;

        return len(n - 1) + numOfDigits(n);
    }

    public static void testLen() {
        Scanner in  = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = in.nextInt();
        System.out.println("len(" + num + ") = " + len(num));
    }

    //*********************Exercise 1.4 GCD*********************
    public static int gcd(int a, int b) {
        if (b == 0)
            return a;

        return gcd(b, a % b);
    }

    public static void testGcd() {
        Scanner in  = new Scanner(System.in);
        System.out.print("Enter number 1: ");
        int a = in.nextInt();

        System.out.print("Enter number 2: ");
        int b = in.nextInt();

        System.out.println("gcd(" + a + ", " + b + ") = " + gcd(a, b));
    }
}
