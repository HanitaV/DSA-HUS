package hus.oop.lab.lab03;

import java.util.Scanner;

public class NumberTheory {
    public static void main(String[] args) {
        //tesPerfectAndDeficientNumbers(); //Exercise 3.1
        //testPrimeNumber(); //Exercise 3.2
        //testPrimeFactors(); //Exercise 3.3
        testGCD(); //Exercise 3.4
    }

    //*********************Exercise 3.1 Perfect and Deficient Numbers*********************
    public static boolean isPerfect(int aPosInt) {
        int sum = 0;

        for (int i = 1; i < aPosInt; i++) {
            if (aPosInt % i == 0) {
                sum += i;
            }
        }
        return sum == aPosInt;
    }

    public static boolean isDeficient(int aPosInt) {
        int sum = 0;
        for (int i = 1; i < aPosInt; i++) {
            if (aPosInt % i == 0) {
                sum += i;
            }
        }
        return sum < aPosInt;
    }

    public static void tesPerfectAndDeficientNumbers() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the upper bound: ");
        int upperBound = scanner.nextInt();

        System.out.println("Perfect numbers:");
        int perfectCount = 0;
        for (int i = 1; i <= upperBound; i++) {
            if (isPerfect(i)) {
                System.out.print(i + " ");
                perfectCount++;
            }
        }
        System.out.println("\n[" + perfectCount + " perfect numbers found (" +
                (perfectCount * 100.0 / upperBound) + "%)]");

        System.out.println("\nNeither deficient nor perfect numbers:");
        int neitherCount = 0;
        for (int i = 1; i <= upperBound; i++) {
            if (!isPerfect(i) && !isDeficient(i)) {
                System.out.print(i + " ");
                neitherCount++;
            }
        }
        System.out.println("\n[" + neitherCount + " numbers found (" +
                (neitherCount * 100.0 / upperBound) + "%)]");
    }

    //*********************Exercise 3.2 Prime Numbers*********************
    public static boolean isPrime(int aPosInt) {
        if (aPosInt <= 1) {
            return false; // 0 and 1 are not prime
        }
        for (int i = 2; i * i <= aPosInt; i++) {
            if (aPosInt % i == 0) {
                return false; // Not prime
            }
        }
        return true; // Prime
    }

    public static void testPrimeNumber() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter the upper bound: ");
        int upperBound = scanner.nextInt();

        int primeCount = 0;
        System.out.println("Prime numbers:");
        for (int i = 1; i <= upperBound; i++) {
            if (isPrime(i)) {
                System.out.print(i + " ");
                primeCount++;
            }
        }

        double percentage = (primeCount * 100.0) / upperBound;
        System.out.printf("\n[%d primes found (%.2f%%)]%n", primeCount, percentage);
    }

    //*********************Exercise 3.3 Prime Factors*********************
    public static boolean isProductOfPrimeFactors(int aPosInt) {
        if (aPosInt <= 1) return false;

        int product = 1;
        for (int i = 2; i < aPosInt; i++) {
            if (isPrime(i) && aPosInt % i == 0) {
                product *= i;
            }
        }
        return product == aPosInt;
    }

    public static void testPrimeFactors() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the upper bound: ");
        int upperBound = scanner.nextInt();

        System.out.println("These numbers are equal to the product of prime factors:");
        int count = 0;
        for (int i = 1; i <= upperBound; i++) {
            if (isProductOfPrimeFactors(i)) {
                System.out.print(i + " ");
                count++;
            }
        }
        double percentage = (count * 100.0) / upperBound;
        System.out.printf("\n[%d numbers found (%.2f%%)]%n", count, percentage);
    }

    //*********************Exercise 3.4 Greatest Common Divisor (GCD)*********************
    public static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public static void testGCD() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the first positive integer (a): ");
        int a = scanner.nextInt();
        System.out.print("Enter the second positive integer (b): ");
        int b = scanner.nextInt();

        if (a <= 0 || b <= 0) {
            System.out.println("Both numbers must be positive.");
        } else {
            int result = gcd(a, b);
            System.out.println("GCD of " + a + " and " + b + " is: " + result);
        }
    }
}
