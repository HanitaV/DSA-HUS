package hus.oop.lab.lab06.pointandline;

public class TestLineSub {
    public static void main(String[] args) {
        LineSub l1 = new LineSub(0, 0, 3, 4);
        System.out.println(l1);
        System.out.println("Length of " + l1 + " is " + l1.getLength());
        System.out.println("Gradient of " + l1 + " is " + l1.getGradient());

        Point p1 = new Point(1, 1);
        Point p2 = new Point(2, 3);
        LineSub l2 = new LineSub(p1, p2);
        System.out.println(l2);
        System.out.println("Length of " + l2 + " is " + l2.getLength());
        System.out.println("Gradient of " + l2 + " is " + l2.getGradient());
    }
}

