package hus.oop.lab.lab06.animal;

public class Mamual extends Animal{
    public Mamual(String name) {
        super(name);
    }

    public String toString() {
        return "Mamual[" + super.toString() + "]";
    }
}
