package hus.oop.lab.lab06.animal;

public class Dog extends Mamual {
    public Dog(String name) {
        super(name);
    }

    public void greets() {
        System.out.println("Woof");
    }

    public void greets(Dog another) {
        System.out.println("Woooof");
    }

    public String toString() {
        return "Dog[" + super.toString() + "]";
    }
}
