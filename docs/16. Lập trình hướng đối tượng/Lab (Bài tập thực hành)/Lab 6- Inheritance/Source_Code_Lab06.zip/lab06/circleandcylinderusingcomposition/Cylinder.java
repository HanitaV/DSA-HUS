package hus.oop.lab.lab06.circleandcylinderusingcomposition;

public class Cylinder{
    private Circle base = new Circle();
    private double height;

    public Cylinder() {
    }

    public Cylinder(double radius) {
        base = new Circle(radius);
    }

    public Cylinder(double radius, double height) {
        base = new Circle(radius);
        this.height = height;
    }

    public Cylinder(double radius, double height, String color) {
        base = new Circle(radius, color);
        this.height = height;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getVolume() {
        return base.getArea() * height;
    }

    public double getRadius() {
        return base.getRadius();
    }

    public double getArea() {
        return base.getArea();
    }

    public String toString() {
        return "Cylinder : subclass of" + base.toString()
                + "height=" + height;
    }
}