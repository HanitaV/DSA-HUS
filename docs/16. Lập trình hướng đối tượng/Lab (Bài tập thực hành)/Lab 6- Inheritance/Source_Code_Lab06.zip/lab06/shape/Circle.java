package hus.oop.lab.lab06.shape;

public class Circle extends Shape {
    private double radius = 1.0f;

    public Circle() {
    }

    public Circle (double radius) {
        this.radius = radius;
    }

    public Circle (double radius, String color, boolean filled) {
        this.radius = radius;
        super.setColor(color);
        super.setFilled(filled);
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getArea() {
        return Math.PI*radius*radius;
    }

    public String toString() {
        return "Circle[" + super.toString() + "radius=" + radius + "]";
    }
}