package hus.oop.lab.lab05.mydate;

public class MyDate {
    private int year;
    private int month;
    private int day;

    public static final String[] MONTHS = {"", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    public static final String[] DAYS = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    public static final int[] DAYS_IN_MONTHS = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    public MyDate(int year, int month, int day) {
        setDate(year, month, day);
    }

    public static boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

    public static boolean isValidDate(int year, int month, int day) {
        if (month == 2 && day == 29 && isLeapYear(year)) {
            return true;
        }

        if (year < 1 || year > 9999 || month < 1 || month > 12 || day < 1 || day > DAYS_IN_MONTHS[month]) {
            return false;
        }

        return true;
    }

    public static int getDayOfWeek(int year, int month, int day) {
        int[] t = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
        year -= month < 3 ? 1 : 0;
        return (year + year / 4 - year / 100 + year / 400 + t[month - 1] + day) % 7;
    }

    public void setDate(int year, int month, int day) {
        if (!isValidDate(year, month, day)) {
            throw new IllegalArgumentException("Invalid year, month, or day!");
        }
        this.year = year;
        this.month = month;
        this.day = day;
    }

    public void setYear(int year) {
        if (year < 1 || year > 9999) {
            throw new IllegalArgumentException("Invalid year!");
        }
        this.year = year;
    }

    public void setMonth(int month) {
        if (month < 1 || month > 12) {
            throw new IllegalArgumentException("Invalid month!");
        }
        this.month = month;
    }

    public void setDay(int day) {
        if (day < 1 || day > DAYS_IN_MONTHS[month]) {
            throw new IllegalArgumentException("Invalid day!");
        }
        if (month == 2 && day == 29 && !isLeapYear(year)) {
            throw new IllegalArgumentException("Invalid day for February in non-leap year!");
        }
        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    public MyDate nextDay() {
        if (day < DAYS_IN_MONTHS[month] || (month == 2 && day == 28 && isLeapYear(year))) {
            day++;
        } else {
            day = 1;
            if (month == 12) {
                month = 1;
                year++;
            } else {
                month++;
            }
        }
        return this;
    }

    public MyDate nextMonth() {
        if (month == 12) {
            year++;
            month = 1;
        } else {
            month++;
        }
        if (day > DAYS_IN_MONTHS[month]) {
            day = DAYS_IN_MONTHS[month];
        }
        return this;
    }

    public MyDate nextYear() {
        year++;
        if (month == 2 && day == 29 && !isLeapYear(year)) {
            day = 28;
        }
        return this;
    }

    public MyDate previousDay() {
        if (day > 1) {
            day--;
        } else {
            if (month == 1) {
                month = 12;
                year--;
            } else {
                month--;
            }
            day = DAYS_IN_MONTHS[month];
        }
        return this;
    }

    public MyDate previousMonth() {
        if (month == 1) {
            year--;
            month = 12;
        } else {
            month--;
        }
        if (day > DAYS_IN_MONTHS[month]) {
            day = DAYS_IN_MONTHS[month];
        }
        return this;
    }

    public MyDate previousYear() {
        year--;
        if (month == 2 && day == 29 && !isLeapYear(year)) {
            day = 28;
        }
        return this;
    }

    @Override
    public String toString() {
        int dayOfWeek = getDayOfWeek(year, month, day);
        return DAYS[dayOfWeek] + " " + day + " " + MONTHS[month] + " " + year;
    }
}