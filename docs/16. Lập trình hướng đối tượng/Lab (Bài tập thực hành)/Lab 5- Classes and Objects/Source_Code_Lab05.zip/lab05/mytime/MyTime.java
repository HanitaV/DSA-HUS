package hus.oop.lab.lab05.mytime;

public class MyTime {
    private int hour;
    private int minute;
    private int second;

    public MyTime(int hour, int minute, int second) {
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public int getSecond() {
        return second;
    }

    public void setSecond(int second) {
        this.second = second;
    }

    public void setTime(int hour, int minute, int second){
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }

    @Override
    public String toString() {
        String timeString = "";

        if (hour < 10) {
            timeString += "0" + hour + ":";
        } else {
            timeString += hour + ":";
        }

        if (minute < 10) {
            timeString += "0" + minute + ":";
        } else {
            timeString += minute + ":";
        }

        if (second < 10) {
            timeString += "0" + second;
        } else {
            timeString += minute;
        }

        return timeString;
    }

    public MyTime nextHour() {
        if (hour < 23) {
            hour++;
        } else {
            hour = 0;
        }

        return this;
    }

    public MyTime nextMinute() {
        if (minute < 59) {
            minute++;
        } else {
            minute = 0;
            nextHour();
        }

        return this;
    }

    public MyTime nextSecond() {
        if (second < 59) {
            second++;
        } else {
            second = 0;
            nextMinute();
        }

        return this;
    }

    public MyTime previousHour() {
        if (hour > 0) {
            hour--;
        } else {
            hour = 23;
        }

        return this;
    }

    public MyTime previousMinute() {
        if (minute > 0) {
            minute--;
        } else {
            minute = 59;
            previousHour();
        }

        return this;
    }

    public MyTime previousSecond() {
        if (second > 0) {
            second--;
        } else {
            second = 59;
            previousMinute();
        }

        return this;
    }
}