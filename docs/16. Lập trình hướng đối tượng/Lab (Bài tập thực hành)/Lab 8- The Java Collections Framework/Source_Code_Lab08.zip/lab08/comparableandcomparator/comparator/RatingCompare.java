package hus.oop.lab.lab08.comparableandcomparator.comparator;

import java.util.*;

/**
 * Class to compare Movies by ratings
 */
class RatingCompare implements Comparator<Movie> {
    public int compare(Movie left, Movie right) {
        return Double.compare(left.getRating(), right.getRating());
    }
}