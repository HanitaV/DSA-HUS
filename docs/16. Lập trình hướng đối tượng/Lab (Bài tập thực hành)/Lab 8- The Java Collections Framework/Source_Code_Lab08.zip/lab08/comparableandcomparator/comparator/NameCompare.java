package hus.oop.lab.lab08.comparableandcomparator.comparator;

import java.util.*;

/**
 * Class to compare Movies by name
 */
class NameCompare implements Comparator<Movie> {
    public int compare(Movie left, Movie right) {
        return left.getName().compareTo(right.getName());
    }
}