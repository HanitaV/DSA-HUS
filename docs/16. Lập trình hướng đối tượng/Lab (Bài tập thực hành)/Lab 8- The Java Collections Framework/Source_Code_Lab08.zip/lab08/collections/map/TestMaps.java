package hus.oop.lab.lab08.collections.map;

import java.util.*;

public class TestMaps {
    public static void main(String[] args) {
        // Creating a sample map
        Map<Integer, Integer> map = new HashMap<>();
        map.put(1, 10);
        map.put(2, 20);
        map.put(3, 30);
        map.put(4, 40);

        // Test count
        System.out.println("Number of key-value mappings: " + Maps.count(map));

        // Test empty
        Maps.empty(map);
        System.out.println("Map after emptying: " + map);

        // Refill the map for further testing
        map.put(1, 100);
        map.put(2, 200);
        map.put(3, 300);
        map.put(4, 400);

        // Test contains
        System.out.println("Contains key 2? " + Maps.contains(map, 2));

        // Test containsKeyValue
        System.out.println("Contains key-value pair (3, 300)? " + Maps.containsKeyValue(map, 3, 300));

        // Test keySet
        Set<Integer> keys = Maps.keySet(map);
        System.out.println("Keys of the map: " + keys);

        // Test values
        Collection<Integer> values = Maps.values(map);
        System.out.println("Values of the map: " + values);

        // Test getColor
        System.out.println("Color for value 1: " + Maps.getColor(1));
        System.out.println("Color for value 2: " + Maps.getColor(2));
        System.out.println("Color for value 3: " + Maps.getColor(3));
        System.out.println("Color for value 4: " + Maps.getColor(4));
        System.out.println("Color for value 5: " + Maps.getColor(5));
    }
}
