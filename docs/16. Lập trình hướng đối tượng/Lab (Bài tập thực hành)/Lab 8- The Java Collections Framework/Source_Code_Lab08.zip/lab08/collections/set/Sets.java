package hus.oop.lab.lab08.collections.set;

import java.util.*;
public class Sets {
    /**
     * Function returning the intersection of two given sets
     * (without using library functions)
     */
    public static Set<Integer> intersectionManual(Set<Integer> first, Set<Integer> second) {
        Set<Integer> intersection = new TreeSet<>();
        Iterator<Integer> iterator = first.iterator();
        while (iterator.hasNext()) {
            Integer value = iterator.next();
            if (second.contains(value)) {
                intersection.add(value);
            }
        }
        return intersection;
    }

    /**
     * Function returning the union of two given sets
     * (without using library functions)
     */
    public static Set<Integer> unionManual(Set<Integer> first, Set<Integer> second) {
        Set<Integer> union = new TreeSet<>();
        Iterator<Integer> iterator1 = first.iterator();
        while (iterator1.hasNext()) {
            Integer value = iterator1.next();
            union.add(value);
        }
        Iterator<Integer> iterator2 = second.iterator();
        while (iterator2.hasNext()) {
            Integer value = iterator2.next();
            union.add(value);
        }
        return union;
    }

    /**
     * Function returning the intersection of two given sets (see retainAll())
     */
    public static Set<Integer> intersection(Set<Integer> first, Set<Integer> second) {
        Set<Integer> intersectionSet = new TreeSet<>(first);
        intersectionSet.retainAll(second);
        return intersectionSet;
    }

    /**
     * Function returning the union of two given sets (see addAll())
     */
    public static Set<Integer> union(Set<Integer> first, Set<Integer> second) {
        Set<Integer> unionSet = new TreeSet<>(first);
        unionSet.addAll(second);
        return unionSet;
    }

    /**
     * Function to transform a set into a list without duplicates
     * Note well: collections can be created from another collection!
     */
    public static List<Integer> toList(Set<Integer> source) {
        return new ArrayList<>(source);
    }

    /**
     * Function to remove duplicates from a list
     * Note well: collections can be created from another collection!
     */
    public static List<Integer> removeDuplicates(List<Integer> source) {
        return new ArrayList<>(new TreeSet<>(source));
    }
    /**
     * Function to remove duplicates from a list without using the constructors trick seen above
     */
    public static List<Integer> removeDuplicatesManual(List<Integer> source) {
        List<Integer> ans = new ArrayList<>();
        Iterator<Integer> iterator = source.iterator();
        while (iterator.hasNext()) {
            Integer value = iterator.next();
            if (!ans.contains(value)) {
                ans.add(value);
            }
        }
        return ans;
    }

    /**
     * Function accepting a string s
     * returning the first recurring character
     * For example firstRecurringCharacter("abaco") -> a.
     */
    public static char firstRecurringCharacter(String s) {
        Set<Character> set = new HashSet<>();
        for (char c : s.toCharArray()) {
            if (!set.add(c)) {
                return c;
            }
        }
        return '\0'; // No recurring character found
    }

    /**
     * Function accepting a string s,
     * and returning a set comprising all recurring characters.
     * For example allRecurringChars("mamma") -> [m, a].
     */
    public static Set<Character> allRecurringChars(String s) {
        Set<Character> set = new HashSet<>();
        Set<Character> recurringChars = new HashSet<>();
        for (char c : s.toCharArray()) {
            if (!set.add(c)) {
                recurringChars.add(c);
            }
        }
        return recurringChars;
    }

    /**
     * Function to transform a set into an array
     */
    public static Integer[] toArray(Set<Integer> source) {
        Integer[] ans = new Integer[source.size()];
        return source.toArray(ans);
    }

    /**
     * Function to return the first item from a TreeSet
     * Note well: use TreeSet specific methods
     */
    public static int getFirst(TreeSet<Integer> source) {
        return source.first();
    }

    /**
     * Function to return the last item from a TreeSet
     * Note well: use TreeSet specific methods
     */
    public static int getLast(TreeSet<Integer> source) {
        return source.last();
    }

    /**
     * Function to get an element from a TreeSet
     * which is strictly greater than a given element.
     * Note well: use TreeSet specific methods
     */
    public static int getGreater(TreeSet<Integer> source, int value) {
        Integer greater = source.higher(value);
        return greater != null ? greater : Integer.MIN_VALUE;
    }
}
