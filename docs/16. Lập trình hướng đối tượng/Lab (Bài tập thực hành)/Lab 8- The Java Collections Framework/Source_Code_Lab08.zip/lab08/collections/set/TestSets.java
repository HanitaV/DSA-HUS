package hus.oop.lab.lab08.collections.set;

import java.util.*;

public class TestSets {
    public static void main(String[] args) {
        // Test intersectionManual
        Set<Integer> set1 = new HashSet<>(Arrays.asList(1, 2, 3, 4, 5));
        Set<Integer> set2 = new HashSet<>(Arrays.asList(4, 5, 6, 7, 8));
        Set<Integer> intersection1 = Sets.intersectionManual(set1, set2);
        System.out.println("Intersection (manual): " + intersection1);

        // Test unionManual
        Set<Integer> union1 = Sets.unionManual(set1, set2);
        System.out.println("Union (manual): " + union1);

        // Test intersection
        Set<Integer> intersection2 = Sets.intersection(set1, set2);
        System.out.println("Intersection: " + intersection2);

        // Test union
        Set<Integer> union2 = Sets.union(set1, set2);
        System.out.println("Union: " + union2);

        // Test toList
        List<Integer> list = Sets.toList(set1);
        System.out.println("List from set: " + list);

        // Test removeDuplicates
        List<Integer> duplicates = new ArrayList<>(Arrays.asList(1, 2, 2, 3, 3, 4, 5, 5));
        List<Integer> unique = Sets.removeDuplicates(duplicates);
        System.out.println("List after removing duplicates: " + unique);

        // Test removeDuplicatesManual
        List<Integer> uniqueManual = Sets.removeDuplicatesManual(duplicates);
        System.out.println("List after removing duplicates manually: " + uniqueManual);

        // Test firstRecurringCharacter
        String str1 = "abaco";
        char recurring1 = Sets.firstRecurringCharacter(str1);
        System.out.println("First recurring character in '" + str1 + "': " + recurring1);

        // Test allRecurringChars
        String str2 = "mamma";
        Set<Character> recurringChars = Sets.allRecurringChars(str2);
        System.out.println("All recurring characters in '" + str2 + "': " + recurringChars);

        // Test toArray
        Integer[] array = Sets.toArray(set1);
        System.out.println("Array from set: " + Arrays.toString(array));

        // Test getFirst
        TreeSet<Integer> treeSet = new TreeSet<>(set1);
        int first = Sets.getFirst(treeSet);
        System.out.println("First element in TreeSet: " + first);

        // Test getLast
        int last = Sets.getLast(treeSet);
        System.out.println("Last element in TreeSet: " + last);

        // Test getGreater
        int greater = Sets.getGreater(treeSet, 3);
        System.out.println("Greater element than 3 in TreeSet: " + greater);
    }
}
