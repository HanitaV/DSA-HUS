package hus.oop.lab.lab08.collections.list;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class TestLists {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        System.out.println("Original list: " + numbers);

        // Test insertFirst
        Lists.insertFirst(numbers, 0);
        System.out.println("After inserting at the beginning: " + numbers);

        // Test insertLast
        Lists.insertLast(numbers, 6);
        System.out.println("After inserting at the end: " + numbers);

        // Test replace
        Lists.replace(numbers, 10);
        System.out.println("After replacing the 3rd element: " + numbers);

        // Test removeThird
        Lists.removeThird(numbers);
        System.out.println("After removing the 3rd element: " + numbers);

        // Test removeEvil
        numbers.addAll(Arrays.asList(666, 7, 666, 8, 666)); // Add some "evil" numbers
        System.out.println("Before removing evil: " + numbers);
        Lists.removeEvil(numbers);
        System.out.println("After removing evil: " + numbers);

        // Test generateSquare
        List<Integer> squares = Lists.generateSquare();
        System.out.println("Square numbers: " + squares);

        // Test contains
        System.out.println("Contains 10? " + Lists.contains(numbers, 10));

        // Test copy
        List<Integer> copiedList = new ArrayList<>();
        Lists.copy(numbers, copiedList);
        System.out.println("Copied list: " + copiedList);

        // Test reverse
        Lists.reverse(numbers);
        System.out.println("Reversed list: " + numbers);

        // Test reverseManual
        Lists.reverseManual(numbers);
        System.out.println("Manually reversed list: " + numbers);

        // Test insertBeginningEnd
        LinkedList<Integer> linkedList = new LinkedList<>(Arrays.asList(1, 2, 3));
        System.out.println("Original linked list: " + linkedList);
        Lists.insertBeginningEnd(linkedList, 0);
        System.out.println("After inserting at the beginning and the end: " + linkedList);
    }
}
