package hus.oop.lab.lab10.adapterpattern.image;

public interface JPEGImageViewer {
    void displayJPEG(String filename);
}
