package hus.oop.lab.lab10.adapterpattern.image;

public class JPEGToBMPAdapter implements BMPImageViewer {
        private JPEGImageViewer jpegViewer;

        public JPEGToBMPAdapter(JPEGImageViewer jpegViewer) {
            this.jpegViewer = jpegViewer;
        }

        @Override
        public void displayBMP(String filename) {
            System.out.println("Converting JPEG to BMP: " + filename);
            jpegViewer.displayJPEG(filename);
        }
}
