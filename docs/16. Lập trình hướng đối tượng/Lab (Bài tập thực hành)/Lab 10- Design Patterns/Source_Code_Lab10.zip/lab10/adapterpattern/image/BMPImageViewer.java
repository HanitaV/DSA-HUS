package hus.oop.lab.lab10.adapterpattern.image;

public interface BMPImageViewer {
    void displayBMP(String filename);
}
