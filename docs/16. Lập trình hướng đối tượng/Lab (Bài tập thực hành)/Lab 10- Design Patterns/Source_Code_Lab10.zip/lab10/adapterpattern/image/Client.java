package hus.oop.lab.lab10.adapterpattern.image;

public class Client {
    public static void main(String[] args) {
        BMPImageViewer bmpViewer = new LegacyBMPImageViewer();
        bmpViewer.displayBMP("image1.bmp");

        JPEGImageViewer jpegViewer = new NewJPEGImageViewer();
        jpegViewer.displayJPEG("image2.jpeg");

        BMPImageViewer adapter = new JPEGToBMPAdapter(new NewJPEGImageViewer());
        adapter.displayBMP("image3.jpeg");
    }
}
