package hus.oop.lab.lab10.adapterpattern.image;

class NewJPEGImageViewer implements JPEGImageViewer {
    @Override
    public void displayJPEG(String filename) {
        System.out.println("Displaying JPEG image: " + filename);
    }
}