package hus.oop.lab.lab10.adapterpattern.image;

class LegacyBMPImageViewer implements BMPImageViewer {
    @Override
    public void displayBMP(String filename) {
        System.out.println("Displaying BMP image: " + filename);
    }
}
