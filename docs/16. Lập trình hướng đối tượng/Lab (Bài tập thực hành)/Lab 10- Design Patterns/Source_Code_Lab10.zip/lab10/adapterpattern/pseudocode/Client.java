package hus.oop.lab.lab10.adapterpattern.pseudocode;

public class Client {
    public static void main(String[] args) {
        RoundHole hole = new RoundHole(5);
        RoundPeg roundPeg = new RoundPeg(5);
        System.out.println("Round peg fits in round hole: " + hole.fits(roundPeg));

        SquarePeg smallSquarePeg = new SquarePeg(5);
        SquarePegAdapter smallSquarePegAdapter = new SquarePegAdapter(smallSquarePeg);
        System.out.println("Square peg (with adapter) fits in round hole: " + hole.fits(smallSquarePegAdapter));

        SquarePeg largeSquarePeg = new SquarePeg(10);
        SquarePegAdapter largeSquarePegAdapter = new SquarePegAdapter(largeSquarePeg);
        System.out.println("Large square peg (with adapter) fits in round hole: " + hole.fits(largeSquarePegAdapter));
    }
}
