package hus.oop.lab.lab10.decoratorpattern.icecream;

public abstract class ToppingDecorator extends IceCream{
    protected IceCream iceCream;
    public ToppingDecorator(IceCream iceCream) {
        this.iceCream = iceCream;
    }
    public abstract String getDescription();
    public abstract String addTopping();
}
