package hus.oop.lab.lab10.decoratorpattern.icecream;

public class ChocolateIceCream extends IceCream{
    @Override
    public String getDescription() {
        return "Ice cream: chocolate";
    }
}