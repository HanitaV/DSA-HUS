package hus.oop.lab.lab10.decoratorpattern.icecream;

public abstract class IceCream {
    public abstract String getDescription();
}