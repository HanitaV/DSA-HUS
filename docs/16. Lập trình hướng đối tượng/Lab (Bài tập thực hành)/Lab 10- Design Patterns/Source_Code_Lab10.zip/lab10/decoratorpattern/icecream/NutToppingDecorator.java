package hus.oop.lab.lab10.decoratorpattern.icecream;

public class NutToppingDecorator extends ToppingDecorator{
    public NutToppingDecorator(IceCream iceCream) {
        super(iceCream);
    }

    @Override
    public String getDescription() {
        return iceCream.getDescription() + ", nut";
    }

    @Override
    public String addTopping() {
        return "add nut";
    }
}