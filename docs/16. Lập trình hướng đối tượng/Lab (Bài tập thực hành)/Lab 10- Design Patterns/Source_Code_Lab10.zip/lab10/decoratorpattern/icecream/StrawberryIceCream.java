package hus.oop.lab.lab10.decoratorpattern.icecream;

public class StrawberryIceCream extends IceCream {
    @Override
    public String getDescription() {
        return "Ice cream: Strawberry ice cream";
    }
}