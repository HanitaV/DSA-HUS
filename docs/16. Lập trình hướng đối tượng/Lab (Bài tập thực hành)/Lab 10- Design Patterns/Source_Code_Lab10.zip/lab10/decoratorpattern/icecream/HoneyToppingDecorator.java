package hus.oop.lab.lab10.decoratorpattern.icecream;

public class HoneyToppingDecorator extends ToppingDecorator{
    public HoneyToppingDecorator(IceCream iceCream) {
        super(iceCream);
    }

    @Override
    public String getDescription() {
        return iceCream.getDescription() + " Honey topping";
    }

    @Override
    public String addTopping() {
        return "add honey";
    }
}