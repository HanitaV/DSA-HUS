package hus.oop.lab.lab10.decoratorpattern.icecream;

public class VanillaIceCream extends IceCream{
    @Override
    public String getDescription() {
        return "Ice cream: Vanillla ice cream";
    }
}
