package hus.oop.lab.lab10.decoratorpattern.icecream;

public class Client {
    public static void main(String[] args) {
        IceCream ic1 = new ChocolateIceCream();
        IceCream ic2 = new HoneyToppingDecorator(new VanillaIceCream());
        System.out.println(ic1.getDescription());
        System.out.println(ic2.getDescription());
    }
}
