package hus.oop.lab.lab10.decoratorpattern.pseudocode;

public class ThincrustPizza extends Pizza {
    public ThincrustPizza() {
        description = "Thin crust pizza, with tomato sauce";
    }

    @Override
    public double cost() {
        return 7.99;
    }
}
