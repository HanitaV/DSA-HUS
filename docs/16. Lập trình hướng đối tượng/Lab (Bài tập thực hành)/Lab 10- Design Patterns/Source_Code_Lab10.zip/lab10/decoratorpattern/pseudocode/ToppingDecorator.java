package hus.oop.lab.lab10.decoratorpattern.pseudocode;

public abstract class ToppingDecorator extends Pizza {
    protected Pizza pizza;

    public abstract String getDescription();

}
