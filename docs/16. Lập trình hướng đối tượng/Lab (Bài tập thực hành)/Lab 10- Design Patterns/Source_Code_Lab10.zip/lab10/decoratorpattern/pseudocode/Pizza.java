package hus.oop.lab.lab10.decoratorpattern.pseudocode;

public abstract class Pizza {
    protected String description = "Basic Pizza";

    public String getDescription() {
        return description;
    }

    public abstract double cost();
}
