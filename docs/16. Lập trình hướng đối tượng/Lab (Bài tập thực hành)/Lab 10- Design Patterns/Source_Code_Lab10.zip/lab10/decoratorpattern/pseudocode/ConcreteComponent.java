package hus.oop.lab.lab10.decoratorpattern.pseudocode;

public class ConcreteComponent extends AbstractComponent {
    @Override
    public void execute() {
        System.out.println("ConcreteComponent.execute()");
    }
}
