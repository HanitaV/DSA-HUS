package hus.oop.lab.lab10.decoratorpattern.pseudocode;

public class BaseDecorator extends AbstractComponent{
    private final AbstractComponent component;
    protected BaseDecorator(AbstractComponent component) {
        this.component = component;
    }

    @Override
    public void execute() {
        this.component.execute();
    }
}
