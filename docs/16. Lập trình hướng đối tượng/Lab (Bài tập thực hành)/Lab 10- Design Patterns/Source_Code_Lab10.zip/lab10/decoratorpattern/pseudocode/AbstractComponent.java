package hus.oop.lab.lab10.decoratorpattern.pseudocode;

public abstract class AbstractComponent {
    public abstract void execute();
}
