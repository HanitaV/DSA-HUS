package hus.oop.lab.lab10.decoratorpattern.shape;

public class Rectangle implements Shape{
    @Override
    public void draw() {
        System.out.println("Shape: Rectangle");
    }
}
