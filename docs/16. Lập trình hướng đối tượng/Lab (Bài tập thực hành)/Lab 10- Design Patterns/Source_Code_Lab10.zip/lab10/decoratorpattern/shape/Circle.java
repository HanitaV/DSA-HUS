package hus.oop.lab.lab10.decoratorpattern.shape;

public class Circle implements Shape{
    @Override
    public void draw() {
        System.out.println("Shape: Circle");
    }
}