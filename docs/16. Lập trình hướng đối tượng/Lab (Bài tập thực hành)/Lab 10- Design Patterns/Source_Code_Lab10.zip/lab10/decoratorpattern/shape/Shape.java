package hus.oop.lab.lab10.decoratorpattern.shape;

public interface Shape {
    void draw();
}