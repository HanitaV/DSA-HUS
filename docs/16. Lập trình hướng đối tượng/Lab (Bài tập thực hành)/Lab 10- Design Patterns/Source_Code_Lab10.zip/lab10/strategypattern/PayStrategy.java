package hus.oop.lab.lab10.strategypattern;

public interface PayStrategy {
    boolean pay(int paymentAmount);
    void collectPaymentDetails();

}
