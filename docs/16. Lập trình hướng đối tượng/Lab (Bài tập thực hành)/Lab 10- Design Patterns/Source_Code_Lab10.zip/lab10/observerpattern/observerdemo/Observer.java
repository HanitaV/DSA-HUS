package hus.oop.lab.lab10.observerpattern.observerdemo;

public abstract class Observer {
    protected Subject subject;
    public abstract void update();
}
