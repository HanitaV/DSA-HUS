package hus.oop.lab.lab10.observerpattern.observer;

public interface Observer {
    public void update(String message);
}
