package hus.oop.lab.lab10.sigletonpattern.pseudocode;

public class Database {
    private static Database instance;

    private Database() {
        // Initialization code, such as connecting to a database server.
    }

    public static Database getInstance() {
        if (instance == null) {
            instance = new Database();
        }
        return instance;
    }

    public void query(String sql) {
        System.out.println("Executing query: " + sql);
    }
}
