package hus.oop.lab.lab10.sigletonpattern.pseudocode;

public class Application {
    public static void main(String[] args) {
        Database foo = Database.getInstance();
        foo.query("SELECT ...");

        // Both foo and bar will reference the same Database instance
        Database bar = Database.getInstance();
        bar.query("SELECT ...");
    }
}
