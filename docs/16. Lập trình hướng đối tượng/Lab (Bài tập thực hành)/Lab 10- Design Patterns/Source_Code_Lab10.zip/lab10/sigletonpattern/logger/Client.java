package hus.oop.lab.lab10.sigletonpattern.logger;

public class Client {
    public static void main(String[] args) {
        Logger logger = Logger.getInstance();

        logger.log("Starting the application...");
        logger.log("Processing data...");
        logger.log("Application finished.");

        Logger logger2 = Logger.getInstance();

        System.out.println("Are logger and logger2 the same instance? " + (logger == logger2));
    }
}
