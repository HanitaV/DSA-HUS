package hus.oop.lab.lab10.sigletonpattern.logger;

public class Logger {
    private static Logger instance;

    private Logger() {
    }

    // Static method to get the singleton instance
    public static synchronized Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    public void log(String message) {
        System.out.println("[LOG] " + message);
    }
}
