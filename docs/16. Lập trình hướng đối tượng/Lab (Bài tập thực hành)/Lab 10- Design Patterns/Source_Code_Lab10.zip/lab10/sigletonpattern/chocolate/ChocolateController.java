package hus.oop.lab.lab10.sigletonpattern.chocolate;

public class ChocolateController {
    public static void main(String[] args) {
        ChocolateBoiler boiler = ChocolateBoiler.getInstance();
        boiler.fill();
        boiler.boil();
        boiler.drain();

        // Getting the existing instance
        ChocolateBoiler boiler2 = ChocolateBoiler.getInstance();
    }
}
