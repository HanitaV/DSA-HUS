package hus.oop.lab.lab10.sigletonpattern.chocolate;

public class ChocolateBoiler {
    private static ChocolateBoiler uniqueInstance; // Singleton instance

    private boolean empty;
    private boolean boiled;

    private ChocolateBoiler() {
        empty = true;
        boiled = false;
    }

    public static ChocolateBoiler getInstance() {
        if (uniqueInstance == null) {
            uniqueInstance = new ChocolateBoiler(); // Create a new instance if it doesn't exist
            System.out.println("Creating unique instance of Chocolate Boiler");
        }
        System.out.println("Returning instance of Chocolate Boiler");
        return uniqueInstance; // Return the existing instance
    }

    public void fill() {
        if (isEmpty()) {
            empty = false;
            boiled = false;
            // Fill the boiler with a milk/chocolate mixture
        }
    }

    public void drain() {
        if (!isEmpty() && isBoiled()) {
            // Drain the boiled milk and chocolate
            empty = true;
        }
    }

    public void boil() {
        if (!isEmpty() && !isBoiled()) {
            // Bring the contents to a boil
            boiled = true;
        }
    }

    public boolean isEmpty() {
        return empty;
    }

    public boolean isBoiled() {
        return boiled;
    }
}
