package hus.oop.lab.lab02;

import java.util.Scanner;

public class StringAndCharacterExercise {
    //********************************Exercises on String and char Operations********************************
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //testReverseString(); //Exercise 1.1
        //testCountVowelsDigits(); //Exercise 1.2
        //testPhoneKeyPad(); //Exercise 1.3
        //testCipherCaesarCode(); //Exercise 1.4
        //testDecipherCaesarCode(); //Exercise 1.5
        //testHexString(); //Exercise 1.6
        //testBinaryToDecimal(); //Exercise 1.7
        //testHexadecimalToDecimal(); //Exercise 1.8
        //testOctalToDecimal(); //Exercise 1.9
        testRadixNToDecimal(); //Exercise 1.10
    }

    //********************************Exercise 1.1 ReverseString********************************
    public static String reverseString(String inStr) {
        // Use inStr.charAt(index) in a loop to extract each character
        // The String’s index begins at 0 from the left.
        // Process the String from the right
        int inStrLen = inStr.length();
        String outStr = "";
        for (int charIdx = inStrLen - 1; charIdx >= 0; --charIdx) {
            // charIdx = inStrLen -1, inStrLen -2, ..., 0
            outStr += inStr.charAt(charIdx);
        }

        return outStr;
    }
    public static void testReverseString() {
        // Define variables
        String inStr;            // input String
        int inStrLen;            // length of the input String

        Scanner in = new Scanner(System.in);
        // Prompt and read input as "String"
        System.out.print("Enter a String: ");
        inStr = in.next();       // use next() to read a String
        inStrLen = inStr.length();

        System.out.println("The reverse of the String ”" + inStr + "” is ”" + reverseString(inStr) + "”");
    }

    //********************************Exercise 1.2 CountVowwelsDigits********************************
    public static int countVowels (String inStr) {
        int inStrLen = inStr.length();
        int count = 0;
        String Vowels = "ueoai";

        for (int i = 0; i < inStrLen; i++)
            if (Vowels.indexOf(inStr.charAt(i)) != -1)
                ++count;

        return count;
    }
    public static int countDigits (String inStr) {
        int inStrLen = inStr.length();
        int count = 0;

        for (int i = 0; i < inStrLen; i++)
            if (Character.isDigit(inStr.charAt(i)))
                ++count;

        return count;
    }
    public static void testCountVowelsDigits() {
        // Define variables
        String inStr;            // input String
        int inStrLen;            // length of the input String

        Scanner in = new Scanner(System.in);
        // Prompt and read input as "String"
        System.out.print("Enter a String: ");
        inStr = in.next().toLowerCase();       // use next() to read a String
        inStrLen = inStr.length();

        System.out.printf("Number of vowels: %d (%.2f%%) \n", countVowels(inStr), 100.0 * countVowels(inStr) / inStrLen);
        System.out.printf("Number of digits: %d (%.2f%%) \n", countDigits(inStr), 100.0 * countDigits(inStr) / inStrLen);
    }

    //********************************Exercise 1.3 PhoneKeyPad********************************
    public static void phoneKeyPad(String inStr) {
        int inStrLen = inStr.length();
        for (int i = 0; i < inStrLen; i++) {
            switch (inStr.charAt(i)) {
                case 'a':
                case 'b':
                case 'c':
                    System.out.print(2);
                    break;

                case 'd':
                case 'e':
                case 'f':
                    System.out.print(3);
                    break;

                case 'g':
                case 'h':
                case 'i':
                    System.out.print(4);
                    break;

                case 'j':
                case 'k':
                case 'l':
                    System.out.print(5);
                    break;

                case 'm':
                case 'n':
                case 'o':
                    System.out.print(6);
                    break;

                case 'p':
                case 'q':
                case 'r':
                case 's':
                    System.out.print(7);
                    break;

                case 't':
                case 'u':
                case 'v':
                    System.out.print(8);
                    break;

                case 'w':
                case 'x':
                case 'y':
                case 'z':
                    System.out.print(9);
                    break;
            }
        }

        System.out.println();
    }
    public static void testPhoneKeyPad() {
        // Define variables
        String inStr;            // input String
        int inStrLen;            // length of the input String

        Scanner in = new Scanner(System.in);
        // Prompt and read input as "String"
        System.out.print("Enter a String: ");
        inStr = in.next().toLowerCase();       // use next() to read a String
        inStrLen = inStr.length();

        System.out.print("The sequence of keyboard digits of String ”" + inStr + "” is ");
        phoneKeyPad(inStr);
    }

    //********************************Exercise 1.4 Caesar's Code********************************
    public static String cipherCaesarCode(String inStr) {
        int inStrLen = inStr.length();            // length of the input String
        String caesarStr = "";

        for (int i = 0; i < inStrLen; i++)
            if (inStr.charAt(i) >= 'A' && inStr.charAt(i) <= 'W')
                caesarStr += (char)(inStr.charAt(i) + 3);
            else if (inStr.charAt(i) == 'X')
                caesarStr += 'A';
            else if (inStr.charAt(i) == 'Y')
                caesarStr += 'B';
            else
                caesarStr += 'C';

        return caesarStr;
    }
    public static void testCipherCaesarCode() {
        // Define variables
        String inStr;            // input String

        Scanner in = new Scanner(System.in);
        // Prompt and read input as "String"
        System.out.print("Enter a plaintext string: ");
        inStr = in.next().toUpperCase();       // use next() to read a String

        System.out.println("The ciphertext string is: " + cipherCaesarCode(inStr));
    }

    //********************************Exercise 1.5 Decipher Caesar's Code********************************
    public static String decipherCaesarCode(String inStr) {
        int inStrLen = inStr.length();            // length of the input String
        String plainStr = "";

        for (int i = 0; i < inStrLen; i++)
            if (inStr.charAt(i) >= 'D' && inStr.charAt(i) <= 'W')
                plainStr += (char)(inStr.charAt(i) - 3);
            else if (inStr.charAt(i) == 'A')
                plainStr += 'X';
            else if (inStr.charAt(i) == 'B')
                plainStr += 'Y';
            else
                plainStr += 'Z';

        return plainStr;
    }
    public static void testDecipherCaesarCode() {
        // Define variables
        String inStr;            // input String

        Scanner in = new Scanner(System.in);
        // Prompt and read input as "String"
        System.out.print("Enter a ciphertext string: ");
        inStr = in.next().toUpperCase();       // use next() to read a String

        System.out.println("The plaintext string is: " + decipherCaesarCode(inStr));
    }

    //********************************Exercise 1.6 CheckHexString********************************
    public static boolean isHexString(String hexStr) {
        int hexStrLen = hexStr.length();            // length of the input String

        for (int i = 0; i < hexStrLen; i++)
            if (!((hexStr.charAt(i) >= '0' && hexStr.charAt(i) <= '9')
                || (hexStr.charAt(i) >= 'A' && hexStr.charAt(i) <= 'F')))
                return false;

        return true;
    }
    public static void testHexString() {
        // Define variables
        String inStr;            // input String

        Scanner in = new Scanner(System.in);
        // Prompt and read input as "String"
        System.out.print("Enter a hex string: ");
        inStr = in.next().toUpperCase();       // use next() to read a String

        System.out.print("”" + inStr + "” is");
        if (isHexString(inStr))
            System.out.println(" a hex string");
        else
            System.out.println(" NOT a hex string");
    }

    //********************************Exercise 1.7 CheckHexString********************************
    public static int binaryToDecimal(String binStr) {
        int binStrLen = binStr.length();            // length of the Binary String
        int decimal = 0;
        int pow = 1;        // power of 2

        for (int i =  binStrLen - 1; i >= 0; i--) {
            if (binStr.charAt(i) != '0' && binStr.charAt(i) != '1')
                return -1;
            else if (binStr.charAt(i) == '1')
                decimal += pow;

            pow *= 2;
        }

        return decimal;
    }
    public static void testBinaryToDecimal() {
        // Define variables
        String binStr;            // Binary String

        Scanner in = new Scanner(System.in);
        // Prompt and read input as "String"
        System.out.print("Enter a Binary string: ");
        binStr = in.next();     // use next() to read a String

        if (binaryToDecimal(binStr) != - 1)
            System.out.println("The equiment decimal number for binary ”" + binStr + "” is: " + binaryToDecimal(binStr));
        else
            System.out.println("error: invalid binary string ”" + binStr + "”");
    }

    //********************************Exercise 1.8 HexadecimalToDecimal********************************
    public static int hexadecimalToDecimal(String hexStr) {
        int hexStrLen = hexStr.length();            // length of the Hexadecimal String
        int decimal = 0;
        int pow = 1;        // power of 16

        for (int i =  hexStrLen - 1; i >= 0; i--) {
            if (hexStr.charAt(i) >= '0' && hexStr.charAt(i) <= '9')
                decimal += (hexStr.charAt(i) - '0') * pow;
            else if (hexStr.charAt(i) >= 'a' && hexStr.charAt(i) <= 'f')
                decimal += (hexStr.charAt(i) - 'a' + 10) * pow;
            else
                return -1;

            pow *= 16;
        }

        return decimal;
    }
    public static void testHexadecimalToDecimal() {
        // Define variables
        String hexStr;            // Hexadecimal String

        Scanner in = new Scanner(System.in);
        // Prompt and read input as "String"
        System.out.print("Enter a Hexadecimal string: ");
        hexStr = in.next();     // use next() to read a String

        if (hexadecimalToDecimal(hexStr) != - 1)
            System.out.println("The equiment decimal number for hexadecimal ”" + hexStr + "” is: " + hexadecimalToDecimal(hexStr));
        else
            System.out.println("error: invalid hexadecimal string ”" + hexStr + "”");
    }

    //********************************Exercise 1.9 OctalToDecimal********************************
    public static int OctalToDecimal(String octalStr) {
        int octalStrLen = octalStr.length();            // length of the Octal String
        int decimal = 0;
        int pow = 1;        // power of 16

        for (int i =  octalStrLen - 1; i >= 0; i--) {
            if (octalStr.charAt(i) >= '0' && octalStr.charAt(i) <= '7')
                decimal += (octalStr.charAt(i) - '0') * pow;
            else
                return -1;

            pow *= 8;
        }

        return decimal;
    }
    public static void testOctalToDecimal() {
        // Define variables
        String octalStr;            // Octal String

        Scanner in = new Scanner(System.in);
        // Prompt and read input as "String"
        System.out.print("Enter a Octal string: ");
        octalStr = in.next();     // use next() to read a String

        if (OctalToDecimal(octalStr) != - 1)
            System.out.println("The equiment decimal number for Octal ”" + octalStr + "” is: " + OctalToDecimal(octalStr));
        else
            System.out.println("error: invalid Octal string ”" + octalStr + "”");
    }

    //********************************Exercise 1.9 RadixNToDecimal********************************
    public static int RadixNToDecimal(String radixNStr, int radix) {
        int radixNStrLen = radixNStr.length();            // length of the RadixN String
        int decimal = 0;
        int pow = 1;        // power of 16

        for (int i =  radixNStrLen - 1; i >= 0; i--) {
            if (radixNStr.charAt(i) >= '0' && radixNStr.charAt(i) <= '9')
                decimal += (radixNStr.charAt(i) - '0') * pow;
            else
                decimal += (radixNStr.charAt(i) - 'a' + 10) * pow;

            pow *= radix;
        }

        return decimal;
    }
    public static void testRadixNToDecimal() {
        // Define variables
        String radixNStr;            // RadixN String
        int radix;

        Scanner in = new Scanner(System.in);
        // Prompt and read input as "String"
        System.out.print("Enter the radix: ");
        radix = in.nextInt();
        System.out.print("Enter the string: ");
        radixNStr = in.next();     // use next() to read a String

        System.out.println("The equiment decimal number for ”" + radixNStr + "” is: " + RadixNToDecimal(radixNStr, radix));
    }
}