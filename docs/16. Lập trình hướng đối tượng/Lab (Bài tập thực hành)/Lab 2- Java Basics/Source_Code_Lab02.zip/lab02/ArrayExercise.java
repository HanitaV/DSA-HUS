package hus.oop.lab.lab02;

import java.util.Scanner;

public class ArrayExercise {
    //********************************Exercises on Array********************************
    public static void main(String[] args) {
        //testPrintArray(); //Exercise 2.1
        //testGradesStatistics(); //Exercise 2.2
        //testHexadecimalToBinary(); //Exercise 2.3
        testDecimalToHexadecimal(); //Exercise 2.4
    }

    //********************************Exercise 2.1 PrintArray********************************
    public static int[] createArray(Scanner in) {
        int numItems;
        System.out.print("Enter the number of items: ");
        numItems = in.nextInt();

        int arr[] = new int[numItems];
        System.out.print("Enter the value of all items (separated by space): ");
        for(int i = 0; i < numItems; i++)
            arr[i] = in.nextInt();

        return arr;
    }

    public static void printArray(int[] arr) {
        int n = arr.length; // Size of Array

        System.out.print("The values are: [");
        for (int i = 0; i < n - 1; i++)
            System.out.print(arr[i] + ", ");
        System.out.println(arr[n - 1] + "]");
    }

    public static void testPrintArray() {
        Scanner sc = new Scanner(System.in);
        printArray(createArray(sc));
    }

    //********************************Exercise 2.2 GradesStatistics********************************
    public static int[] generateStudentGrades(Scanner in) {
        int numStudents;
        System.out.print("Enter the number of students: ");
        numStudents = in.nextInt();

        int grades[] = new int[numStudents];
        for(int i = 0; i < numStudents; i++) {
            System.out.print("Enter the grade for student " + (i + 1) + ": ");
            grades[i] = in.nextInt();
        }

        return grades;
    }

    public static void simpleGradesStatistics(int[] grades) {
        int numStudents = grades.length; // Size of Array
        int sum = 0;
        int minimum = grades[0];
        int maximum = grades[0];

        for (int i = 0; i < numStudents; i++){
            sum += grades[i];

            if (grades[i] < minimum)
                minimum = grades[i];

            if (grades[i] > maximum)
                maximum = grades[i];
        }

        System.out.printf("The average is: %.2f \n", 1.0 * sum / numStudents);
        System.out.println("The minimum is: " + minimum);
        System.out.println("The maximum is: " + maximum);
    }

    public static void testGradesStatistics() {
        Scanner sc = new Scanner(System.in);
        simpleGradesStatistics(generateStudentGrades(sc));
    }

    //********************************Exercise 2.3 HexadecimalToBinary********************************
    public static String hexadecimalToBinary(String hexStr) {
        int hexStrLen = hexStr.length();

        final String[] HEXBITS = {"0000", "0001", "0010", "0011",
                "0100", "0101", "0110", "0111",
                "1000", "1001", "1010", "1011",
                "1100", "1101", "1110", "1111"};

        String binary = "";
        for (int i = 0; i < hexStrLen; i++)
            if (hexStr.charAt(i) >= '0' && hexStr.charAt(i) <= '9')
                binary += HEXBITS[hexStr.charAt(i) - '0'] + " ";
            else if (hexStr.charAt(i) >= 'a' && hexStr.charAt(i) <= 'f')
                binary += HEXBITS[hexStr.charAt(i) - 'a' + 10] + " ";
            else
                throw new IllegalArgumentException("Invalid hexadecimal character: " + hexStr.charAt(i));

        return binary;
    }

    public static void testHexadecimalToBinary() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a Hexadecimal string: ");
        String hexStr;
        hexStr = sc.next().toLowerCase();

        try {
            System.out.println("The equivalent binary for hexadecimal ”" + hexStr + "” is: "
                    + hexadecimalToBinary(hexStr));
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    //********************************Exercise 2.4 DecimalToHexadecimal********************************
    public static String decimalToHexadecimal(int positiveInteger) {
        String hexadecimal = "";
        while (positiveInteger != 0) {
            if (positiveInteger % 16 < 10)
                hexadecimal = (char) ('0' + positiveInteger % 16) + hexadecimal;
            else
                hexadecimal = (char) ('A' + positiveInteger % 16 - 10) + hexadecimal;

            positiveInteger /= 16;
        }

        return  hexadecimal;
    }

    public static void  testDecimalToHexadecimal() {
        Scanner sc = new Scanner(System.in);
        int positiveInteger;
        System.out.print("Enter a decimal number: ");
        positiveInteger = sc.nextInt();
        System.out.println("The quivalent hexadecimal number is " + decimalToHexadecimal(positiveInteger));
    }
}