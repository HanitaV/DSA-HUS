package hus.oop.lab.lab02;

import java.util.Scanner;

public class MethodExercise {
    //********************************Exercises on Method********************************
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //testExpoment(); //Exercise 3.1
        //testMagicSum(sc); //Exercise 3.2
        //testPrintArray(sc); //Exercise 3.3
        //testArrayToString(sc); //Exercise 3.4
        //testContains(sc); //Exercise 3.5
        //testSearch(sc); //Exercise 3.6
        //testEqual(sc); //Exercise 3.7
        //testCopyOf(sc); //Exercise 3.8
        //testSwap(sc); //Exercise 3.9
        testRevese(sc); //Exercise 3.10
    }

    //********************************Exercise 3.1 expoment********************************
    public static int exponent(int base, int exp) {
        int Exponent = 1;
        for (int i = 1; i <= exp; i++)
            Exponent *= base;

        return Exponent;
    }
    public static void testExpoment() {
        Scanner sc = new Scanner(System.in);
        int base, exp;

        System.out.print("Enter the base: ");
        base = sc.nextInt();

        System.out.print("Enter the exponent: ");
        exp = sc.nextInt();

        System.out.println(base + " raises to power of " + exp + " is: " + exponent(base, exp));
    }

    //********************************Exercise 3.2 hasEight********************************
    public static boolean haseEight(int number) {
        while(number > 0) {
            if (number % 10 == 8)
                return true;

            number /= 10;
        }

        return false;
    }
    public static void testMagicSum(Scanner in) {
        int number;
        System.out.print("Enter a positive integer (or -1 to end): ");
        number = in.nextInt();

        int sum = 0;
        while (number != -1) {
            if (haseEight(number))
                sum += number;

            System.out.print("Enter a positive integer (or -1 to end): ");
            number = in.nextInt();
        }

        System.out.println("The magic sum is: " + sum);
    }

    //********************************Exercise 3.3 printArray********************************
    public static void printArray(int[] arr) {
        int n = arr.length; // Size of Array

        System.out.print("[");
        for (int i = 0; i < n - 1; i++)
            System.out.print(arr[i] + ", ");
        System.out.println(arr[n - 1] + "]");
    }

    public static void testPrintArray(Scanner in)  {
        int numItems;
        System.out.print("Enter the number of items: ");
        numItems = in.nextInt();

        int arr[] = new int[numItems];
        System.out.print("Enter the value of all items (separated by space): ");
        for(int i = 0; i < numItems; i++)
            arr[i] = in.nextInt();

        printArray(arr);
    }

    //********************************Exercise 3.4 arrayToString********************************
    public static String arrayToString(int[] arr) {
        int n = arr.length; // Size of Array

        String str = "[";
        for (int i = 0; i < n - 1; i++)
            str += arr[i] + ", ";

        str += arr[n - 1] + "]";

        return str;
    }

    public static void testArrayToString(Scanner in)  {
        int numItems;
        System.out.print("Enter the number of items: ");
        numItems = in.nextInt();

        int arr[] = new int[numItems];
        System.out.print("Enter the value of all items (separated by space): ");
        for(int i = 0; i < numItems; i++)
            arr[i] = in.nextInt();

        System.out.println("Convert to String: " + arrayToString(arr));
    }

    //********************************Exercise 3.5 contains********************************
    public static boolean contains(int[] arr, int key) {
        int n = arr.length; // Size of Array

        for (int i = 0; i < n - 1; i++)
            if (arr[i] == key)
                return true;

        return false;
    }

    public static void testContains(Scanner in)  {
        int numItems;
        System.out.print("Enter the number of items: ");
        numItems = in.nextInt();

        int arr[] = new int[numItems];
        System.out.print("Enter the value of all items (separated by space): ");
        for(int i = 0; i < numItems; i++)
            arr[i] = in.nextInt();

        int key;
        System.out.print("Enter key: ");
        key = in.nextInt();

        if (contains(arr, key))
            System.out.println(key + " is found in array!");
        else
            System.out.println(key + " is NOT found in array!");
    }

    //********************************Exercise 3.6 search********************************
    public static int search(int[] arr, int key) {
        int n = arr.length; // Size of Array

        for (int i = 0; i < n - 1; i++)
            if (arr[i] == key)
                return i;

        return -1;
    }

    public static void testSearch(Scanner in)  {
        int numItems;
        System.out.print("Enter the number of items: ");
        numItems = in.nextInt();

        int arr[] = new int[numItems];
        System.out.print("Enter the value of all items (separated by space): ");
        for(int i = 0; i < numItems; i++)
            arr[i] = in.nextInt();

        int key;
        System.out.print("Enter key: ");
        key = in.nextInt();

        if (search(arr, key) != -1)
            System.out.println(key + " is found in index: " + search(arr, key));
        else
            System.out.println(key + " is NOT found in array!");
    }

    //********************************Exercise 3.7 equals********************************
    public static boolean equals(int[] arr1, int[] arr2) {
        int n1 = arr1.length; // Size of Array 1
        int n2 = arr2.length; // Size of Array 2

        if (n1 != n2) return false;

        for (int i = 0; i < n1 - 1; i++)
            if (arr1[i] != arr2[i])
                return false;

        return true;
    }

    public static void testEqual(Scanner in)  {
        int numItems1;
        System.out.print("Enter the number of items in array 1: ");
        numItems1 = in.nextInt();

        int arr1[] = new int[numItems1];
        System.out.print("Enter the value of all items (separated by space): ");
        for(int i = 0; i < numItems1; i++)
            arr1[i] = in.nextInt();

        int numItems2;
        System.out.print("Enter the number of items in array 2: ");
        numItems2 = in.nextInt();

        int arr2[] = new int[numItems2];
        System.out.print("Enter the value of all items (separated by space): ");
        for(int i = 0; i < numItems2; i++)
            arr2[i] = in.nextInt();

        if (equals(arr1, arr2))
            System.out.println("Array 1 equals Array2");
        else
            System.out.println("Array 1 NOT equals Array2");
    }

    //********************************Exercise 3.8 copyOf********************************
    public static int[] copyOf(int[] array) {
        int size = array.length;
        int copyArray[] = new int[size];

        for(int i = 0; i < size; i++)
            copyArray[i] = array[i];

        return copyArray;
    }

    public static void testCopyOf(Scanner in)  {
        int numItems;
        System.out.print("Enter the number of items in array : ");
        numItems = in.nextInt();

        int arr[] = new int[numItems];
        System.out.print("Enter the value of all items (separated by space): ");
        for(int i = 0; i < numItems; i++)
            arr[i] = in.nextInt();

        System.out.print("Copy of Array is ");
        printArray(copyOf(arr));
    }

    //********************************Exercise 3.9 swap********************************
    public static boolean swap(int[] arr1, int[] arr2) {
        int n1 = arr1.length; // Size of Array 1
        int n2 = arr2.length; // Size of Array 2

        if (n1 != n2) return false;

        for (int i = 0; i < n1 - 1; i++) {
            int temp;
            temp = arr1[i];
            arr1[i] = arr2[i];
            arr2[i] = temp;
        }

        return true;
    }

    public static void testSwap(Scanner in)  {
        int numItems1;
        System.out.print("Enter the number of items in array 1: ");
        numItems1 = in.nextInt();

        int arr1[] = new int[numItems1];
        System.out.print("Enter the value of all items (separated by space): ");
        for(int i = 0; i < numItems1; i++)
            arr1[i] = in.nextInt();

        int numItems2;
        System.out.print("Enter the number of items in array 2: ");
        numItems2 = in.nextInt();

        int arr2[] = new int[numItems2];
        System.out.print("Enter the value of all items (separated by space): ");
        for(int i = 0; i < numItems2; i++)
            arr2[i] = in.nextInt();

        if (equals(arr1, arr2))
            System.out.println("Array 1 swaps Array2");
        else
            System.out.println("Array 1 NOT swaps Array2");
    }

    //********************************Exercise 3.10 reverse********************************
    public static void reverse(int[] array) {
        int size = array.length;
        int copyArray[] = new int[size];

        int left = 0;
        int right = size - 1;
        while (left <= right) {
            int temp = array[left];
            array[left] = array[right];
            array[right] = temp;
            ++left;
            --right;
        }
    }

    public static void testRevese(Scanner in)  {
        int numItems;
        System.out.print("Enter the number of items in array : ");
        numItems = in.nextInt();

        int arr[] = new int[numItems];
        System.out.print("Enter the value of all items (separated by space): ");
        for(int i = 0; i < numItems; i++)
            arr[i] = in.nextInt();

        System.out.print("Reverse of Array is ");
        reverse(arr);
        printArray(arr);
    }
}

