package hus.oop.lab.lab01;

import java.util.Scanner;

public class SumAverageRunningInt {
    public static void getSumAndAverageByFor(int LOWERBOUND, int UPPERBOUND) {
        int sum = 0;
        int count = 0;
        double average;

        for (int number = LOWERBOUND; number <= UPPERBOUND; number++) {
            sum += number;
            count++;
        }

        average = (double) sum/ count;
        System.out.println("The sum of " + LOWERBOUND + " to " + UPPERBOUND + " is " + sum);
        System.out.println("The average is " + average);
    }

    public static void getSumAndAverageByWhileDo(int LOWERBOUND, int UPPERBOUND) {
        int sum = 0;
        int count = 0;
        int number = LOWERBOUND;
        double average;

        while (number <= UPPERBOUND) {
            sum += number;
            count++;
            number++;
        }

        average = (double) sum/ count;
        System.out.println("The sum of " + LOWERBOUND + " to " + UPPERBOUND+  " is " + sum);
        System.out.println("The average is " + average);
    }

    public static void getSumAndAverageByDoWhile(int LOWERBOUND, int UPPERBOUND) {
        int sum = 0;
        int count = 0;
        int number = LOWERBOUND;
        double average;

        do {
            sum += number;
            ++count;
            ++number;
        } while (number <= UPPERBOUND);

        average = (double) sum/ count;
        System.out.println("The sum of " + LOWERBOUND + " to " + UPPERBOUND+  " is " + sum);
        System.out.println("The average is " + average);
    }

    public static void getSumOfTheSquares(int LOWERBOUND, int UPPERBOUND) {
        long sum = 0;

        for (int number = LOWERBOUND; number <= UPPERBOUND; number++) {
            sum += number*number;
        }

        System.out.println("The sum of the squares from " + LOWERBOUND + " to " + UPPERBOUND + " is " + sum);
    }

    public static void getSumOfOddEvenNumber(int LOWERBOUND, int UPPERBOUND) {
        int sumOdd = 0, sumEven = 0;

        for (int number = LOWERBOUND; number <= UPPERBOUND; number++) {
            if (number % 2 == 0)
                sumEven += number;
            else
                sumOdd += number;
        }

        int absDiff = Math.abs(sumOdd - sumEven);
        System.out.println("The sum odd numbers of " + LOWERBOUND + " to " + UPPERBOUND + " is " + sumOdd);
        System.out.println("The sum even numbers of " + LOWERBOUND + " to " + UPPERBOUND + " is " + sumEven);
        System.out.println("The subtract absolute of sum odd numbers and even numbers is " + absDiff);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        final int LOWERBOUND = sc.nextInt();
        final int UPPERBOUND = sc.nextInt();

        System.out.println("The LOWERBOUND is: " + LOWERBOUND);
        System.out.println("The UPPERBOUND is: " + UPPERBOUND);

        getSumAndAverageByFor(LOWERBOUND, UPPERBOUND);
        getSumAndAverageByWhileDo(LOWERBOUND, UPPERBOUND);
        getSumAndAverageByWhileDo(LOWERBOUND, UPPERBOUND);
        getSumOfTheSquares(LOWERBOUND, UPPERBOUND);
        getSumOfOddEvenNumber(LOWERBOUND, UPPERBOUND);
    }
}