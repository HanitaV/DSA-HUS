package hus.oop.lab.lab01;

import java.util.Scanner;

public class CheckPassFail { // Save as "CheckPassFail.java"
    public static void Check(int mark) {
        System.out.println("The mark is " + mark);

        // if-else statement
        if (mark >= 50) {
            System.out.println("PASS");
        } else {
            System.out.println("FAIL");
        }

        System.out.println("DONE");
    }
    public static void main(String[] args) { // Program entry point
        Scanner sc = new Scanner(System.in);
        int mark = sc.nextInt();

        Check(mark);
    }
}
