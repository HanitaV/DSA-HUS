package hus.oop.lab.lab01;

import java.util.Scanner;

public class SumProductMinMax3 {
    public static void findMin(int number1, int number2, int number3) {
        int min = number1;
        if (min > number2) {
            min = number2;
        }
        if (min > number3) {
            min = number3;
        }
        System.out.println("The min is : " + min);
    }

    public static void findMax(int number1, int number2, int number3) {
        int max = number1;
        if (max < number2) {
            max = number2;
        }
        if (max < number3) {
            max = number3;
        }
        System.out.println("The min is : " + max);
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter 1st integer: ");
        int number1 = sc.nextInt();
        System.out.print("Enter 2nd integer: ");
        int number2 = sc.nextInt();
        System.out.print("Enter 3rd integer: ");
        int number3 = sc.nextInt();

        int sum;
        int product;

        sum = number1 + number2 + number3;
        product = number1 * number2 * number3;

        System.out.println("The sum is : " + sum);
        System.out.println("The product is : " + product);

        findMin(number1, number2, number3);
        findMax(number1, number2, number3);
    }
}
