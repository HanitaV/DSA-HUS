package hus.oop.lab.lab01;

public class ComputePI {
    public static void piWithMAX_DENOMINATOR() {
        int MAX_DENOMINATOR = 1000;
        double sum = 0.0;

        for (int denominator = 1; denominator <= MAX_DENOMINATOR; denominator += 2) {
            if (denominator % 4 == 1) {
                sum += 1.0 / denominator;
            } else if (denominator % 4 == 3) {
                sum -= 1.0 / denominator;
            } else {
                System.out.println("Impossible!!!");
            }
        }

        sum *= 4.0;
        double pi = Math.PI;
        double percentageDifferece = (sum / pi) * 100;
        System.out.println("Percentage difference: " + percentageDifferece);
    }
    public static void piWithMAX_TERM() {
        int MAX_TERM = 10000;
        double sum = 0.0;

        for(int term = 1; term <= MAX_TERM; term++) {
            if(term % 2 == 1) {
                sum += 1.0 / (term * 2 - 1);
            }
            else {
                sum -= 1.0 / (term * 2 - 1);
            }
        }

        double pi = Math.PI;
        double percentageDifferece = (sum / pi) * 100;
        System.out.println("Percentage difference: " + percentageDifferece);

    }

    public static void main(String[] args) {
        piWithMAX_DENOMINATOR();
        piWithMAX_TERM();
    }
}
