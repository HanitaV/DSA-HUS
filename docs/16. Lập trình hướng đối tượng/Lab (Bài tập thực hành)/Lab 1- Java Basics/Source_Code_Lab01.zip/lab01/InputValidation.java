package hus.oop.lab.lab01;

import java.util.Scanner;

public class InputValidation {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numberInt;
		boolean isValid;
		
		isValid = false;
		while(!isValid) {
			System.out.print("Enter the number between 0-10 or 90-100: ");
			numberInt = sc.nextInt();

			if (numberInt >= 0 && numberInt <= 10) {
				isValid = true;
				System.out.print("You have entered: " + numberInt);
				
			} else if (numberInt >= 90 && numberInt <= 100) {
				isValid = true;
				System.out.print("You have entered: " + numberInt);
			} else {
				System.out.print("Invalid input try again...\n");
			}
		}
	}
}
