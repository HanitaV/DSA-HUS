package hus.oop.lab.lab01;

import java.util.Scanner;

public class ReverseInt {
    public static void getReverseNumber(int inNumber){
        int inDigit;
        int reverseNumber = 0;

        while (inNumber != 0) {
            inDigit = inNumber % 10;
            reverseNumber = reverseNumber * 10 + inDigit;
            inNumber /= 10;
        }

        System.out.println("The reverse is: " + reverseNumber);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a positive integer: ");
        int inNumber = sc.nextInt();

        getReverseNumber(inNumber);
    }
}
