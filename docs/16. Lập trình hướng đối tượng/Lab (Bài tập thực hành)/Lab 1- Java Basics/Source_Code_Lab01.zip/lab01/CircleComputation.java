package hus.oop.lab.lab01;

import java.util.Scanner;

public class CircleComputation {
    public static void getSphereComputation(double radius){
        double surfaceArea = 4 * Math.PI * radius * radius;
        double volume = ((double) 4/3) * Math.PI * radius * radius * radius;

        System.out.printf("The surface area of a sphere is %.2f\n", surfaceArea);
        System.out.printf("The volume of a sphere is %.2f\n", volume);
    }

    public static void getCylinderComputation(double radius, Scanner sc){
        System.out.print("Enter the height ");
        double height = sc.nextDouble();

        double baseArea = Math.PI * radius * radius * 4;
        double surfaceArea = 2.0 * Math.PI * radius + 2.0 * baseArea;
        double volume = baseArea * height;

        System.out.printf("The base area of a cylinder is %.2f\n", baseArea);
        System.out.printf("The surface area of a cylinder is %.2f\n", surfaceArea);
        System.out.printf("The volume of a cylinder is %.2f\n", volume);
    }
    
    public static void main(String[] args) {
        double radius;
        double diameter;

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the radius ");
        radius = sc.nextDouble();

        System.out.print("Enter the diameter ");
        diameter = sc.nextDouble();

        double circumference = diameter * Math.PI;
        double area = radius * radius * Math.PI;

        System.out.printf("Radius is %.2f\n", radius);
        System.out.printf("Diameter is %.2f\n", radius);
        System.out.printf("Circumference is %.2f\n", circumference);
        System.out.printf("Area is %.2f\n", area);
    }
}
