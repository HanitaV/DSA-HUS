package hus.oop.lab.lab01; /**
 * Print factorial of n
 */
import java.util.Scanner;

public class Factorial {
    public static long getFactorial(int n) {
        long factorial = 1;

        // n! = 1 * 2 * 3 ... * n
        for (int i = 1; i <= n; i++) { // i = 1, 2, 3, ..., n
            factorial = factorial * i;
        }

        return factorial;
    }
    public static void main(String[] args) { // Set an initial breakpoint at this statement
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        System.out.println("The Factorial of " + n + " is " + getFactorial(n));
    }
}
