package hus.oop.lab.lab01;

import java.util.Scanner;

public class CheckOddEven { // Save as "CheckOddEven.java"
    public static void checkOddEven (int number) {
        System.out.println("The number is " + number);

        // if-else statement
        if (number % 2 == 0) {
            System.out.println("The number is even.");
        } else {
            System.out.println("The number is odd.");
        }

        System.out.println("Bye!");
    }
    public static void main(String[] args) { // Program entry point
        Scanner sc = new Scanner(System.in);

        int number = sc.nextInt();
        checkOddEven(number);
    }
}
