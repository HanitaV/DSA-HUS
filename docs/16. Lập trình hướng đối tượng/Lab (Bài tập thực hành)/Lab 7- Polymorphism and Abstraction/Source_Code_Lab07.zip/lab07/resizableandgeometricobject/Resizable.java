package hus.oop.lab.lab07.resizableandgeometricobject;

public interface Resizable {
    public void resize(int percent);
}
