package hus.oop.lab.lab07.resizableandgeometricobject;

public class TestCircle {
    public static void main(String[] args) {
        // Create a Circle object with radius 5
        Circle circle = new Circle(5);

        // Test methods
        System.out.println("Circle details:");
        System.out.println("Radius: " + circle.radius);
        System.out.println("Area: " + circle.getArea());
        System.out.println("Perimeter: " + circle.getPerimeter());
        System.out.println("String representation: " + circle.toString());

        // Modify radius and test again
        circle.radius = 7;
        System.out.println("\nCircle details after radius modification:");
        System.out.println("Radius: " + circle.radius);
        System.out.println("Area: " + circle.getArea());
        System.out.println("Perimeter: " + circle.getPerimeter());
        System.out.println("String representation: " + circle.toString());
    }
}