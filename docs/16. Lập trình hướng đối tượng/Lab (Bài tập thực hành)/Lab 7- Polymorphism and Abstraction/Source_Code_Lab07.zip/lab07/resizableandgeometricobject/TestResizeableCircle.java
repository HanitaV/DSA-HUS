package hus.oop.lab.lab07.resizableandgeometricobject;

public class TestResizeableCircle {
    public static void main(String[] args) {
        // Create a ResizeableCircle object with radius 5
        ResizeableCircle circle = new ResizeableCircle(5);

        // Test methods
        System.out.println("ResizableCircle details:");
        System.out.println("Original Radius: " + circle.radius);
        System.out.println("Original Area: " + circle.getArea());
        System.out.println("Original Perimeter: " + circle.getPerimeter());
        System.out.println("String representation: " + circle.toString());

        // Resize the circle by 50%
        circle.resize(50);

        // Test methods after resizing
        System.out.println("\nResizableCircle details after resizing by 50%:");
        System.out.println("New Radius: " + circle.radius);
        System.out.println("New Area: " + circle.getArea());
        System.out.println("New Perimeter: " + circle.getPerimeter());
        System.out.println("String representation: " + circle.toString());
    }
}
