package hus.oop.lab.lab07.resizableandgeometricobject;

public interface GeometricObject {
    public double getArea();
    public double getPerimeter();
}
