package hus.oop.lab.lab07.geometricobject;

public interface GeometricObject {
    public double getArea();
    public double getPerimeter();
}
