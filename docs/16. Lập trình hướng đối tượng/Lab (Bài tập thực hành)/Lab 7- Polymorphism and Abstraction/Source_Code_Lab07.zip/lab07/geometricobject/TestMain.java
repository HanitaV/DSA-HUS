package hus.oop.lab.lab07.geometricobject;

public class TestMain {
    public static void main(String[] args) {
        // Test Circle class
        Circle circle = new Circle(5.5);
        System.out.println("Circle:");
        System.out.println("Area: " + circle.getArea());
        System.out.println("Perimeter: " + circle.getPerimeter());
        System.out.println(circle.toString());

        // Test Rectangle class
        Rectangle rectangle = new Rectangle(4, 6);
        System.out.println("\nRectangle:");
        System.out.println("Area: " + rectangle.getArea());
        System.out.println("Perimeter: " + rectangle.getPerimeter());
        System.out.println(rectangle.toString());
    }
}
