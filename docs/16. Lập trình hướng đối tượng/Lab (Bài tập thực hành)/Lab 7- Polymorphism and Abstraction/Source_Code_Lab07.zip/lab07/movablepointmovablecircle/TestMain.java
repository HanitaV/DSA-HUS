package hus.oop.lab.lab07.movablepointmovablecircle;

public class TestMain {
    public static void main(String[] args) {
        // Test MovablePoint class
        System.out.println("Testing MovablePoint:");
        MovablePoint point = new MovablePoint(3, 4, 1, 1);
        System.out.println("Initial point: " + point);
        point.moveUp();
        point.moveRight();
        System.out.println("After moving up and right: " + point);

        // Test MovableCircle class
        System.out.println("\nTesting MovableCircle:");
        MovableCircle circle = new MovableCircle(1, 2, 1, 1, 5);
        System.out.println("Initial circle: " + circle);
        circle.moveDown();
        circle.moveLeft();
        System.out.println("After moving down and left: " + circle);
    }
}
