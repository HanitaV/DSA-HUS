package hus.oop.lab.lab07.movablepoint;

public interface Movable {
    public void moveUp();

    public void moveDown();

    public void moveLeft();

    public void moveRight();
}