package hus.oop.lab.lab07.superclassshape;

public class Circle extends Shape {
    private double radius = 1.0f;

    public Circle() {
    }

    public Circle (double radius) {
        this.radius = radius;
    }

    public Circle (double radius, String color, boolean filled) {
        this.radius = radius;
        super.setColor(color);
        super.setFilled(filled);
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return Math.PI*radius*radius;
    }

    @Override
    public double getPerimeter() {
        return Math.PI*radius*2;
    }

    @Override
    public String toString() {
        return "Circle[" + super.toString() + "radius=" + radius + "]";
    }
}