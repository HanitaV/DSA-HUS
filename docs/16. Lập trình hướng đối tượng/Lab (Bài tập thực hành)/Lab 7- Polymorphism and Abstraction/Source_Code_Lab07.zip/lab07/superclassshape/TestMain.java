package hus.oop.lab.lab07.superclassshape;

public class TestMain {
    public static void main(String[] args) {
        Shape shape1 = new Circle(5.5, "red", false); // Upcast Circle to Shape
        System.out.println(shape1); // Output: Circle@<some_hexadecimal_number>
        // which version? - Output: Depends on the toString() implementation in Circle class
        System.out.println(shape1.getArea()); // Output: Area of the circle
        System.out.println(shape1.getPerimeter()); // Output: Perimeter of the circle
        System.out.println(shape1.getColor()); // Output: "red"
        System.out.println(shape1.isFilled()); // Output: false
        System.out.println(((Circle) shape1).getRadius()); // Output: 5.5

        Circle circle1 = (Circle) shape1; // Downcast to Circle
        System.out.println(circle1); // Output: Circle@<some_hexadecimal_number>
        System.out.println(circle1.getArea()); // Output: Area of the circle
        System.out.println(circle1.getPerimeter()); // Output: Perimeter of the circle
        System.out.println(circle1.getColor()); // Output: "red"
        System.out.println(circle1.isFilled()); // Output: false
        System.out.println(circle1.getRadius()); // Output: 5.5

        // Note: You cannot instantiate Shape because it's an abstract class.
        // Therefore, the following line will throw a compilation error:
        // Shape shape2 = new Shape();

        // Upcast Rectangle to Shape
        Shape shape3 = new Rectangle(1.0, 2.0, "red", false);
        System.out.println(shape3); // Output: Rectangle@<some_hexadecimal_number>
        System.out.println(shape3.getArea()); // Output: Area of the rectangle
        System.out.println(shape3.getPerimeter()); // Output: Perimeter of the rectangle
        System.out.println(shape3.getColor()); // Output: "red"
        // System.out.println(shape3.getLength()); // Error: Shape class doesn't have getLength method

        Rectangle rectangle1 = (Rectangle) shape3; // Downcast to Rectangle
        System.out.println(rectangle1); // Output: Rectangle@<some_hexadecimal_number>
        System.out.println(rectangle1.getArea()); // Output: Area of the rectangle
        System.out.println(rectangle1.getColor()); // Output: "red"
        System.out.println(rectangle1.getLength()); // Output: Length of the rectangle

        // Upcast Square to Shape
        Shape shape4 = new Square(6.6);
        System.out.println(shape4); // Output: Square@<some_hexadecimal_number>
        System.out.println(shape4.getArea()); // Output: Area of the square
        System.out.println(shape4.getColor()); // Output: Not sure, depends on the Square class implementation
        // System.out.println(shape4.getSide()); // Error: Shape class doesn't have getSide method

        // Downcast Rectangle to Square
        Rectangle rectangle2 = (Rectangle) shape4; // Runtime error, you can't downcast a Square to a Rectangle
        // Therefore, the next lines of code wouldn't execute as intended.
        // You might need to fix the casting logic.
    }
}
