package hus.oop.lab.lab07.interfacemovablemovablepointandmovablecircle;

public class TestRectangle {
    public static void main(String[] args) {
        MovableRectangle rectangle = new MovableRectangle(1, 1, 4, 4, 2, 2);

        System.out.println("Initial position:");
        System.out.println(rectangle);

        rectangle.moveUp();
        System.out.println("After moving up:");
        System.out.println(rectangle);

        rectangle.moveLeft();
        System.out.println("After moving left:");
        System.out.println(rectangle);

        rectangle.moveDown();
        System.out.println("After moving down:");
        System.out.println(rectangle);

        rectangle.moveRight();
        System.out.println("After moving right:");
        System.out.println(rectangle);
    }
}