package hus.oop.lab.lab07.interfacemovablemovablepointandmovablecircle;

public class TestMovable {
    public static void main(String[] args) {
        // Create a MovablePoint object
        Movable m1 = new MovablePoint(5, 6, 10, 15);
        System.out.println(m1); // Output: (5,6) speed=(10,15)
        m1.moveLeft();
        System.out.println(m1); // Output: (15,6) speed=(10,15)

        // Upcast to MovableCircle
        Movable m2 = new MovableCircle(1, 2, 3, 4, 20);
        System.out.println(m2); // Output: (1,2) speed=(3,4)
        m2.moveRight();
        System.out.println(m2); // Output: (4,2) speed=(3,4)
    }
}
