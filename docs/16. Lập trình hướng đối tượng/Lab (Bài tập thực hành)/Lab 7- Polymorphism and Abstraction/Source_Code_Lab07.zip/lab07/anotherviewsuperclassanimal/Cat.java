package hus.oop.lab.lab07.anotherviewsuperclassanimal;

public class Cat extends Animal {
    @Override
    public void greeting() {
        System.out.println("Meow!");
    }
}
