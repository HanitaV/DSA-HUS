package hus.oop.lab.lab07.anotherviewsuperclassanimal;

public class TestAnimal {
    public static void main(String[] args) {
        // Using the subclasses
        Cat cat1 = new Cat();
        cat1.greeting();

        Dog dog1 = new Dog();
        dog1.greeting();

        BigDog bigDog1 = new BigDog();
        bigDog1.greeting();

        // Using Polymorphism
        Animal animal1 = new Cat();
        animal1.greeting();

        Animal animal2 = new Dog();
        animal2.greeting();

        Animal animal3 = new BigDog();
        animal3.greeting();

        // Downcast with instanceof check
        if (animal2 instanceof Dog) {
            Dog dog2 = (Dog) animal2;
            dog2.greeting((Dog) animal3);
        } else {
            System.out.println("animal2 is not an instance of Dog.");
        }

        if (animal3 instanceof BigDog) {
            BigDog bigDog2 = (BigDog) animal3;
            bigDog2.greeting((BigDog) animal2);
        } else {
            System.out.println("animal3 is not an instance of BigDog.");
        }

        if (animal2 instanceof Cat) {
            Cat cat2 = (Cat) animal2;
            cat2.greeting(); // Cat doesn't have greeting(Dog) method
        } else {
            System.out.println("animal2 is not an instance of Cat.");
        }

        if (animal3 instanceof Dog) {
            Dog dog3 = (Dog) animal3;
            dog3.greeting((Dog) animal2);
        } else {
            System.out.println("animal3 is not an instance of Dog.");
        }
    }
}
