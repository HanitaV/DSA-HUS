package hus.oop.lab.lab07.anotherviewsuperclassanimal;

public abstract class Animal {
    abstract public void greeting();
}
