package hus.oop.lab.lab07.anotherviewsuperclassanimal;

public class BigDog extends Dog {
    @Override
    public void greeting() {
        System.out.println("Woow!");
    }

    @Override
    public void greeting(Dog another) {
        System.out.println("Wooooowwwww!");
    }
}
