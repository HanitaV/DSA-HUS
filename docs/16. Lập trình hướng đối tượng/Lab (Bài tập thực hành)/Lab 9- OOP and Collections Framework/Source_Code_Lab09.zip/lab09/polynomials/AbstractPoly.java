package hus.oop.lab.lab09.polynomials;

import java.util.Objects;

public abstract class AbstractPoly implements Poly {

    double[] derive() {
        double[] derivedCoefficients = new double[coefficients().length - 1];
        for (int i = 1; i < coefficients().length; i++) {
            derivedCoefficients[i - 1] = coefficients()[i] * i;
        }
        return derivedCoefficients;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AbstractPoly that = (AbstractPoly) o;
        return Objects.equals(coefficients(), that.coefficients());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(coefficients());
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < coefficients().length; i++) {
            stringBuilder.append(coefficients()[i]);
            if (i != 0) {
                stringBuilder.append("x^").append(i);
            }
            if (i != coefficients().length - 1) {
                stringBuilder.append(" + ");
            }
        }
        return stringBuilder.toString();
    }
}
