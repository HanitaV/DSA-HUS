package hus.oop.lab.lab09.library;

public class Library {
    Rent[] rents;

    public Library(Rent[] rents) {
        this.rents = rents;
    }

    public Rent getLongestRent() {
        Rent longestRent = null;
        long maxDuration = 0;
        for (Rent rent : rents) {
            long duration = rent.getEnd().getTime() - rent.getBegin().getTime();
            if (duration > maxDuration) {
                maxDuration = duration;
                longestRent = rent;
            }
        }
        return longestRent;
    }
}

